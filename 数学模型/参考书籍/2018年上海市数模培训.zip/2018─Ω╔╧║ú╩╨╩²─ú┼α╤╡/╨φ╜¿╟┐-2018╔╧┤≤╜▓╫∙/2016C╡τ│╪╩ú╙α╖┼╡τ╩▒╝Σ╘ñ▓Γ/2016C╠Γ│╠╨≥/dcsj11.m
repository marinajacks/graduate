function yhat=dcsj11(beta,x)
yhat=beta(2)-beta(3)*(x(:,1)-9).^beta(1);